#!/usr/bin/env python
# -*- coding: utf-8 -*-
from mdlJhHrvArchievepy import *
import pytest

@pytest.mark.parametrize('FToken,FYear,FMonth,FOpthon,output',
                         [("057A7F0E-F187-4975-8873-AF71666429AB", "2023","7","账套查询DMS测试", "没有需要同步至ERP的凭证"),
                          ("057A7F0E-F187-4975-8873-AF71666429AB",  "2023","7","账套查询DMS测试", "程序运行完成")])
def test_voucher_save(FToken, FYear, FMonth, FOpthon,output):

    assert voucher_save(FToken=FToken, FYear=FYear, FMonth=FMonth, FOpthon=FOpthon) == output